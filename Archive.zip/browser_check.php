<?php

echo $_SERVER['HTTP_USER_AGENT'] . "\n\n";

// $browser = get_browser(null, true);

// print_r($browser);

?> 
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>

	<script type="text/javascript">
		
		alert(navigator.connection);

	</script>

</body>
</html>